import javax.swing.JPanel;
public interface page {
    public JPanel page();
    public void update(String specific);
}
